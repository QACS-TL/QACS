﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooTycoon
{
    public class Dolphin: Animal
    {
        public Dolphin() : this("Flipper", 3, "BlueyGrey", 3)
        {

        }

        public Dolphin(string name, int limbCount, string colour, int keeperId) : base(name, limbCount, colour, keeperId)
        {
           
        }

        public string Talk(string message)
        {
            //translate message into dolphinese
            message += "click click click";
            return message;
        }

        public override string Eat(string food)
        {
            return $"I'm a {Colour} dolphin called {Name} using my {LimbCount} fins and I don't like {food}. I want FISH!!";
        }

    }
}
