﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooTycoon
{
    public class IceCreamKiosk : IKiosk
    {
        public string KioskType { get; set; }

        public string Colour => "Red and White";

        public void Open()
        {
            throw new NotImplementedException();
        }
    }
}
