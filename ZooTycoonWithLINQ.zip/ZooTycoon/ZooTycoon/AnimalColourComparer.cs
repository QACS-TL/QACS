﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooTycoon
{
    public class AnimalColourComparer : IComparer<Animal>
    {
        public int Compare(Animal? x, Animal? y)
        {
            return x.Colour.CompareTo(y.Colour);
        }
    }
}
