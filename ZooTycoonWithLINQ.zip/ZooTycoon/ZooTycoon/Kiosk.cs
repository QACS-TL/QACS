﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooTycoon
{
    //public abstract class Kiosk
    //{
    //    public abstract string KioskType { get; set; }
    //    public abstract string Colour { get; }

    //    public abstract void Open();
    //}

    public interface IKiosk
    {
        string KioskType { get; set;  }
        string Colour { get; }

        void Open();
    }
}
