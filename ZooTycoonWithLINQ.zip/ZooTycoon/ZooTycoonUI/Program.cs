﻿using ZooTycoon;


//Animal animal1 = new Animal();
//animal1.Name = "Fido";
//animal1.LimbCount = 4;
//animal1.Colour = "Brown";

//Animal animal2 = new Animal();
//animal2.Name = "Fifi";
//animal2.LimbCount = 3;
//animal2.Colour = "Pink";

//Console.WriteLine($"I am a {animal1.Colour} animal called {animal1.Name} and I have {animal1.LimbCount} limbs.");
//Console.WriteLine($"I am a {animal2.Colour} animal called {animal2.Name} and I have {animal2.LimbCount} limbs.");

Dragon dragon1 = new Dragon() { Name = "Dewi", LimbCount = 6 };
Dragon dragon2 = new Dragon() { Name = "Lewi", LimbCount = 8 };
//Animal animal3 = new Animal("Dobbin", 5, "Stripey");
//Animal animal4 = new Animal("Bonzo", 3, "Spotty");
Dolphin dolphin1 = new Dolphin();
Dolphin dolphin2 = new Dolphin("Dennis", 2, "Blue", 3);


List<Animal> animals = new List<Animal>();
//animals.Add(animal1);
//animals.Add(animal2);
animals.Add(dragon1);
animals.Add(dragon2);
//animals.Add(animal3);
//animals.Add(animal4);
animals.Add(dolphin1);
animals.Add(dolphin2);
animals.Add(new Dolphin("Dannie", 3, "Purple", 4));
animals.Add(new Dragon("Arthur", 9, "Green", 50, 2));

List<Keeper> keepers = new List<Keeper>();
keepers.Add(new Keeper() { Id = 1, KName = "Aled Jones", Phone = "0123456789", ManagerId = -1});
keepers.Add(new Keeper() { Id = 2, KName = "Douglas Smith", Phone = "0111111111", ManagerId = 1 });
keepers.Add(new Keeper() { Id = 3, KName = "Tina Jones", Phone = "0122222222", ManagerId = 1 });
keepers.Add(new Keeper() { Id = 4, KName = "Wendy Williams", Phone = "013333333", ManagerId = 3 });



foreach (Animal animal in animals)
{
    Console.WriteLine(animal.Eat("Chocolate"));
    if (animal is Dragon)
    {
        Console.WriteLine(((Dragon)animal).BreatheFire(30));
    }
}
//Name sequence
animals.Sort();
Console.WriteLine("*********************");

foreach (Animal animal in animals)
{
    Console.WriteLine(animal.Eat("Cake"));
}

//Colour sequence
animals.Sort(new AnimalColourComparer());
Console.WriteLine("*********************");

foreach (Animal animal in animals)
{
    Console.WriteLine(animal.Eat("Bananas"));
}

Console.WriteLine($"You created {Animal.AnimalCount}");

IEnumerable<Animal> dolphins = animals.Where(d => d is Dolphin);
foreach (var d in dolphins)
{
    Console.WriteLine(d.Eat("Fish"));
}
Console.WriteLine("*********************");
var animalsAndTheirKeepers = from a in animals
                             join k in keepers
                             on a.KeeperId equals k.Id
                             select new { a.Name, a.KeeperId, k.KName, k.Phone };


foreach(var anim in animalsAndTheirKeepers)
{
    Console.WriteLine($"{anim.Name} is looked after by {anim.KName} contact No: {anim.Phone}");
}

Console.WriteLine("*********************");

var keepersAndTheirManagers = from k in keepers
                            join km in keepers
                            on k.Id equals km.ManagerId
                            select new {k.Id, k.KName, ManagerID= km.Id, ManagerName= km.KName, km.Phone};

foreach(var k in keepersAndTheirManagers)
{
    Console.WriteLine($"{k.KName}: {k.ManagerName}");
}
