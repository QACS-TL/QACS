﻿using Animals;
using Newtonsoft.Json;

Animal animal = new Kangaroo("Fifi", 8, "Stripey", 56.3);
//animal.Name = "Fifi";
animal.LimbCount = -1;
//animal.Colour = "Pink";
//animal.Health = 95;

Elephant animal2 = new Elephant() { Name= "Jumbo", LimbCount= 4, Colour= "Purple", TrunkLength=103, TuskSize= 45};
//animal2.Name = "Fido";
//animal2.LimbCount = 3;
//animal2.Colour = "Yellow";
animal2.Health = 25;

Console.WriteLine(animal.Eat("banana cake"));
Console.WriteLine(animal2.Eat("brownie"));

Kangaroo kangaroo = new Kangaroo("Roo", 6, "Spotty", 23.5) {Health = 100};
//kangaroo.Name = "Kanga";
//kangaroo.Colour = "Brown";
//kangaroo.LimbCount = 4;
//kangaroo.Health = 100;
//kangaroo.TailLength = 46.5;

Console.WriteLine(kangaroo.Hop(6));
Console.WriteLine($"{kangaroo.Name} has a tail length of {kangaroo.TailLength}cm");
Console.WriteLine(kangaroo.Eat("Cheese"));
Console.WriteLine(kangaroo.Move(12, "South"));


List<Animal> animals = new List<Animal>();
animals.Add(animal);
animals.Add(animal2);
animals.Add(new Elephant { Name="Bonzo", Colour="Green", LimbCount=5});
animals.Add(kangaroo);

foreach(Animal ani in animals)
{
    Console.WriteLine($"I'm a {ani.Colour} animal called {ani.Name} and I have {ani.LimbCount} limbs.");
    if (ani is Kangaroo)
    {
        Console.WriteLine($"I'm a kangaroo and I have a tail length of {((Kangaroo)ani).TailLength} cm.");
        //Console.WriteLine(((Kangaroo)ani).Eat("Muesli"));
    }
    Console.WriteLine(ani.Eat("Muesli"));
    //Console.WriteLine(ani.Move(direction:"West", distance:50));
    //Console.WriteLine(ani.Move(50, "East"));
    //Console.WriteLine(ani.Move());
    //Console.WriteLine(ani.Move(45, null));
    Console.WriteLine(ani);
}

Console.WriteLine(Animal.AnimalCount);
string json = JsonConvert.SerializeObject(kangaroo);
Console.WriteLine(json);

int i = 12;

Console.WriteLine(i.ToString());
Console.WriteLine("*********************************");

animals.Sort();

foreach (Animal ani in animals)
{
    Console.WriteLine(ani);
}

Console.WriteLine("*********************************");

animals.Sort(Animal.IAnimalNameComparer);

foreach (Animal ani in animals)
{
    Console.WriteLine(ani);
}

Console.WriteLine("*********************************");

animals.Sort(Animal.IAnimalColourComparer);

foreach (Animal ani in animals)
{
    Console.WriteLine(ani);
}





