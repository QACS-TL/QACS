﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    public class SuperKangaroo:Kangaroo
    {
        public SuperKangaroo():base("Anon", 4, "Brown", 56.7)
        {
            
        }
    }
}
