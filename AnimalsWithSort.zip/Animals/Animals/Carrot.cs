﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    internal class Carrot : IVegetable
    {
        public string Name { get; set; }
        public string Colour { get; set; }
        public int Length { get; set; }

        public void Grow(int increment)
        {
           Length += increment;
        }
    }
}
