﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    public class Elephant : Animal
    {
        public int TrunkLength { get; set; }
        public int TuskSize { get; set; }

        public override string Eat(string food)
        {
            return $"I'm a {Colour} Elephant using my trunk eat {food}";
        }
    }
}
