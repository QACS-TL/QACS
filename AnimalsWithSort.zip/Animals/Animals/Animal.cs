﻿namespace Animals
{
    public abstract class Animal:IComparable<Animal>
    {
        public static int AnimalCount { get; set; } = 0;
        public Animal(string name = "Anon", int limbCount = 4, string colour = "Brown")
        {
            Name = name;
            LimbCount = limbCount;
            Colour = colour;
            AnimalCount++;
        }

        public string Name { get; set; } = "Fred";
        private int limbCount;
 
        public int LimbCount
        {
            get 
            { 
                return limbCount; 
            }
            set 
            {
                if (value < 0)
                {
                    value = 0;
                }
                limbCount = value; 
            }
        }

        private string colour; // = string.Empty;

        //public required string Colour
        public string Colour
        {
            get { return colour; }
            set {
                List<string> validColours = new List<string>() { "Blue", "Red", "Brown", "Pink", "Spotty", "Stripey"};
                if (validColours.Contains(value))
                    colour = value;
                else
                    colour = "Bown";
            }
        }

        public int Health = 100;

        //public virtual string Eat(string food)
        //{
        //    Health += 5;
        //    if (Health > 100) {
        //        Health = 100;
        //    }

        //    return $"I'm a {Colour} animal called {Name} using my {LimbCount} limbs to eat {food}";
        //}
        public abstract string Eat(string food);

        //public string Move(string direction)
        //{
        //    return $"I'm an animal called {Name} moving {direction}";
        //}

        public string Move(int distance)
        {
            return $"I'm an animal called {Name} moving {distance} metres";
        }

        public string Move(int distance = 10, string? direction = "North")
        {
            return $"I'm an animal called {Name} moving {direction} for {distance} metres";
        }

        public override string ToString()
        {
            return  $"I'm a {Colour} animal called {Name} I have {LimbCount} limbs and I have {Health} amount of health.";
        }

        public int CompareTo(Animal? other)
        {
            return this.LimbCount - other.LimbCount;
        }

        private static AnimalNameComparer animalNameComparer = null;
        public static IComparer<Animal> IAnimalNameComparer {
            get
            {
                if (animalNameComparer == null)
                {
                    animalNameComparer = new AnimalNameComparer();
                }
                return animalNameComparer;
            } 
        }

        private class AnimalNameComparer : IComparer<Animal>
        {
            public int Compare(Animal? x, Animal? y)
            {
                return x.Name.CompareTo(y.Name);
            }
        }


        private static AnimalColourComparer animalColourComparer = null;
        public static IComparer<Animal> IAnimalColourComparer
        {
            get
            {
                if (animalColourComparer == null)
                {
                    animalColourComparer = new AnimalColourComparer();
                }
                return animalColourComparer;
            }
        }

        private class AnimalColourComparer : IComparer<Animal>
        {
            public int Compare(Animal? x, Animal? y)
            {
                return x.Colour.CompareTo(y.Colour);
            }
        }

    }
}
