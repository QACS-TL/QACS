﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    public interface IVegetable
    {
        string Name { get; set; }
        string Colour { get; set; }
        int Length { get; set; }

        void Grow(int increment);
    }

    public abstract class Vegetable
    {
        public abstract string Name { get; set; }
        public abstract string Colour { get; set; }
        public abstract int Length { get; set; }

        public abstract void Grow(int increment);
    }
}
