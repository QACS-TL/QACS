﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    public class Kangaroo: Animal
    {
        public Kangaroo(string name, int limbCount, string colour, double tailLength):base(name, limbCount, colour) 
        {
           TailLength = tailLength;
        }

        public double TailLength { get; set; }

        public string Hop(int number = 5)
        {
            string s = string.Empty;
            for (int i = 0; i < number; i++)
            {
                s += "Hop, ";
            }
            s = s[..^2];
            return s;
        }

        public override string Eat(string food)
        {
            return $"I'm a {Colour} Kangaroo stretching to eat {food}";
        }


        public override string ToString()
        {
            return $"I'm a {Colour} KANGAROO called {Name} I have {LimbCount} limbs and I have {Health} amount of health.";
        }
    }
}
