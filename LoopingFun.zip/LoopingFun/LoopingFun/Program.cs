﻿// Arrays are yukky because they are difficult to resize so adding and inserting new values is problematic and inefficient
int[] primes = new int[] {1, 2, 3, 5, 7, 11, 13, 17, 19, 23};

primes[4] = 101;

for (int i = 0; i < primes.Length; i++)
{
    Console.WriteLine(primes[i]);
}
Console.WriteLine("All done!");


List<int> primes2 = new List<int>() { 1, 2, 3, 5, 7, 11, 13, 17, 19, 23 };

primes[4] = 101;
primes2.Add(27);
primes2.Insert(6, 18);
primes2.Remove(3);
primes2.RemoveAt(4);
primes2.AddRange(primes);

for (int i = 0; i < primes2.Count; i++)
{
    Console.WriteLine(primes2[i]);
}
Console.WriteLine("All done Again!");

List<string> customers = new List<string>();
customers.Add("Bobby");
customers.Add("Belinda");
customers.Add("Bobina");

//for loop - allows you to alter/replace values in collection
for (int i = 0; i < customers.Count; i++)
{
    customers[i] = customers[i] + "*";
    Console.WriteLine(customers[i]);
}
Console.WriteLine("All done Again Again!");

customers.Sort();
//foreach loop - gives you read only objects from collection
foreach (string s in customers)
{
    //s = s + "%";
    Console.WriteLine(s);
}

Console.WriteLine("*******************************");
//While Loop (executes zero, one or many times)
int j = 4;
while (j < customers.Count)
{
    Console.WriteLine(customers[j]);
    j++;
}

//Do While Loop (executes one or many times)
j = 0;
do
{
    Console.WriteLine(customers[j]);
    j++;
} while (j < customers.Count);

Console.WriteLine("*******************************");

Dictionary<string, string> contacts = new Dictionary<string, string>();
contacts.Add("Bobby", "0123456789");
contacts["Bobina"] = "999";
contacts.Add("Brian", "0987654321");

contacts["Bobina"] = "8888";

if (contacts.ContainsKey("Bobina"))
{
    Console.WriteLine(contacts["Bobina"]);
}

Console.WriteLine("*******************************");

//Multi dimensional list of lists!
List<List<int>> list = new List<List<int>>();
list.Add(new List<int>() { 2, 4, 6, 8, 10, 12 });
list.Add(new List<int>() { 1, 3, 5, 9, 11, 13 });
list.Add(new List<int>() { 1, 2, 3, 5, 7, 11 });

foreach(List<int> num in list)
{
    foreach(int i in num)
    {
        Console.WriteLine(i);
    }
}
Console.WriteLine("*******************************");

Console.WriteLine(list[2][3]); // prints 5 (third list, 4th entry)

