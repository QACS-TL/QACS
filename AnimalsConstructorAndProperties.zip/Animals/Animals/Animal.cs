﻿namespace Animals
{
    public class Animal
    {
        public Animal(string name = "Anon", int limbCount = 4, string colour = "Brown")
        {
            Name = name;
            LimbCount = limbCount;
            Colour = colour;
        }

        //public Animal(string name, int limbCount):this(name, limbCount, "Brown")
        //{

        //}

        //public Animal(string name) : this(name, 4)
        //{

        //}


        //public Animal() : this("Anon" )
        //{

        //}

       

        public string Name { get; set; }
        private int limbCount;

        //private string name;

        //public string Name
        //{
        //    get { return name; }
        //    set { name = value; }
        //}


        //public int GetLimbCount()
        //{
        //    return limbCount;
        //}

        //public void SetLimbCount(int value)
        //{
        //    if (value < 0)
        //    {
        //        value = 0;
        //    }
        //    limbCount = value;
        //}


        public int LimbCount
        {
            get 
            { 
                return limbCount; 
            }
            set 
            {
                if (value < 0)
                {
                    value = 0;
                }
                limbCount = value; 
            }
        }

        private string colour;

        public string Colour
        {
            get { return colour; }
            set {
                List<string> validColours = new List<string>() { "Blue", "Red", "Brown", "Pink", "Spotty", "Stripey"};
                if (validColours.Contains(value))
                    colour = value;
                else
                    colour = "Bown";
            }
        }

        public int Health = 100;

        public string Eat(string food)
        {
            Health += 5;
            if (Health > 100) {
                Health = 100;
            }

            return $"I'm a {Colour} animal called {Name} using my {LimbCount} limbs to eat {food}";
        }

        //public string Move(string direction)
        //{
        //    return $"I'm an animal called {Name} moving {direction}";
        //}

        public string Move(int distance)
        {
            return $"I'm an animal called {Name} moving {distance} metres";
        }

        public string Move(int distance = 10, string? direction = "North")
        {
            return $"I'm an animal called {Name} moving {direction} for {distance} metres";
        }

    }
}
