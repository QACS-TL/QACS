﻿using Animals;

Animal animal = new Animal("Fifi", 8, "Stripey");
//animal.Name = "Fifi";
animal.LimbCount = -1;
//animal.Colour = "Pink";
//animal.Health = 95;

Animal animal2 = new Animal(); //{ Name="Biffo", LimbCount=4, Colour="Purple"};
//animal2.Name = "Fido";
animal2.LimbCount = 3;
//animal2.Colour = "Yellow";
animal2.Health = 25;

Console.WriteLine(animal.Eat("banana cake"));
Console.WriteLine(animal2.Eat("brownie"));

List<Animal> animals = new List<Animal>();
animals.Add(animal);
animals.Add(animal2);
//animals.Add(new Animal { Name="Bonzo", Colour="Green", LimbCount=6});

foreach(Animal ani in animals)
{
    Console.WriteLine($"I'm a {ani.Colour} animal called {ani.Name} and I have {ani.LimbCount}");
    //Console.WriteLine(ani.Move(direction:"West", distance:50));
    //Console.WriteLine(ani.Move(50, "East"));
    //Console.WriteLine(ani.Move());
    //Console.WriteLine(ani.Move(45, null));
}


