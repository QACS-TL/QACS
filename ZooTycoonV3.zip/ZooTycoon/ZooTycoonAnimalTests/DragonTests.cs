﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using ZooTycoon;

namespace ZooTycoonAnimalTests
{
    public class DragonTests
    {
        [Fact]
        public void InitialDragonTest()
        {
            //Arrange
            Dragon dragon = new Dragon() { Name = "Dewi", LimbCount = 6 };
            dragon.Colour = "Red";
            string expectedMessage = $"I'm a DRAGON ROASTING a child and then, once done, chomping it but leaving some of the bones.";

            //Act
            string message = dragon.Eat("child");

            //Assert
            Assert.Equal(expectedMessage, message);
        }

        [Fact]
        public void InitialDragonAsAnAnimalTest()
        {
            //Arrange
            Dragon dragon = new Dragon() { Name = "Dewi", LimbCount = 6 };
            dragon.Colour = "Red";
            string expectedMessage = $"I'm a DRAGON ROASTING a child and then, once done, chomping it but leaving some of the bones.";

            //Act
            string message = dragon.Eat("child");

            //Assert
            Assert.Equal(expectedMessage, message);
        }


        [Fact]
        public void LoadsOfAnimalsTest()
        {
            //Arrange


            //Assert
            //Assert.Equal(expectedMessage, message);
        }

        [Fact]
        public void DragonMeetsKnightTest()
        {
            //Arrange
            Dragon dragon = new Dragon() { Name = "Dewi", LimbCount = 6 };
            dragon.Colour = "Red";

            //Act
            dragon.LimbCount -= 1;

            //Assert
            Assert.Equal(5, dragon.LimbCount);
        }


        [Fact]
        public void DragonMeetsSuperKnightTest()
        {
            //Arrange
            //Dragon dragon = new Dragon() { Name = "Dewi", LimbCount = 6 };
            //dragon.Colour = "Red";
            Dragon dragon = new Dragon("Dewi", 6, "Red", 200);

            //Act
            string message = dragon.BreatheFire(20);
            dragon.LimbCount -= 7;

            //Assert
            Assert.Equal(0, dragon.LimbCount);
            Assert.Equal(180, dragon.FuelLevel);
            Assert.Equal("I'm a Red dragon ROASTING you for 20 seconds.", message);

        }
    }
}
