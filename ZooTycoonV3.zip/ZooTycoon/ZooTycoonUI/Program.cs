﻿using ZooTycoon;


Animal animal1 = new Animal();
animal1.Name = "Fido";
animal1.LimbCount = 4;
animal1.Colour = "Brown";

Animal animal2 = new Animal();
animal2.Name = "Fifi";
animal2.LimbCount = 3;
animal2.Colour = "Pink";

Console.WriteLine($"I am a {animal1.Colour} animal called {animal1.Name} and I have {animal1.LimbCount} limbs.");
Console.WriteLine($"I am a {animal2.Colour} animal called {animal2.Name} and I have {animal2.LimbCount} limbs.");

Dragon dragon1 = new Dragon() { Name = "Dewi", LimbCount = 6 };
Dragon dragon2 = new Dragon() { Name = "Lewi", LimbCount = 8 };
Animal animal3 = new Animal("Dobbin", 5, "Stripey");
Animal animal4 = new Animal("Bonzo", 3, "Spotty");

List<Animal> animals = new List<Animal>();
animals.Add(animal1);
animals.Add(animal2);
animals.Add(dragon1);
animals.Add(dragon2);
animals.Add(animal3);
animals.Add(animal4);

//Act
foreach (Animal animal in animals)
{
    Console.WriteLine(animal.Eat("Chocolate"));
}