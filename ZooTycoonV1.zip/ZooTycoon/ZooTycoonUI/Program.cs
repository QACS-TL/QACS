﻿using ZooTycoon;


Animal animal1 = new Animal();
animal1.name = "Fido";
animal1.limbCount = 4;
animal1.colour = "Brown";

Animal animal2 = new Animal();
animal2.name = "Fifi";
animal2.limbCount = 3;
animal2.colour = "Pink";

Console.WriteLine($"I am a {animal1.colour} animal called {animal1.name} and I have {animal1.limbCount} limbs.");
Console.WriteLine($"I am a {animal2.colour} animal called {animal2.name} and I have {animal2.limbCount} limbs.");