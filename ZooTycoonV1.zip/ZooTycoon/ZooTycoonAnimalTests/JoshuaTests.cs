﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooTycoonAnimalTests
{
    using ZooTycoon;

    namespace ZooTycoonAnimalTests
    {
        public class AnimalTests
        {
            [Fact]
            public void AnimalCreationTest()
            {

                //Arrange + Act
                Animal animal = new Animal();

                animal.name = "Fido";
                animal.limbCount = 4;
                animal.colour = "Brown";


                //Assert

                Assert.Equal("Fido", animal.name);

                Assert.Equal(4, animal.limbCount);

                Assert.Equal("Brown", animal.colour);

            }



            [Fact]
            public void CreateTwoCreationTest()
            {

                //Arrange + Act

                Animal animal1 = new Animal();

                animal1.name = "Fido";
                animal1.limbCount = 4;
                animal1.colour = "Brown";

                Animal animal2 = new Animal();

                animal2.name = "Fifi";
                animal2.limbCount = 3;
                animal2.colour = "Blue";


                //Assert

                Assert.Equal("Fido", animal1.name);

                Assert.Equal(4, animal1.limbCount);

                Assert.Equal("Brown", animal1.colour);

                Assert.Equal("Fifi", animal2.name);

                Assert.Equal(3, animal2.limbCount);

                Assert.Equal("Blue", animal2.colour);

            }


            [Fact]
            public void CreateTwoAnimalsAndGetThemToEatTest()
            {

                //Arrange + Act

                Animal animal1 = new Animal();

                animal1.name = "Fido";
                animal1.limbCount = 4;
                animal1.colour = "Brown";

                Animal animal2 = new Animal();

                animal2.name = "Josh";
                animal2.limbCount = 3;
                animal2.colour = "Blue";


                string expectedMessage1 = $"I'm a {animal1.colour} animal called {animal1.name} using some of my {animal1.limbCount} limbs to eat Cheese.";
                string expectedMessage2 = $"I'm a Blue animal called Josh using some of my 3 limbs to eat Banana.";

                //Act

                string message1 = animal1.Eat("Cheese");
                string message2 = animal2.Eat("Banana");

                //Assert

                Assert.Equal(expectedMessage1, message1);
                Assert.Equal(expectedMessage2, message2);



            }

        }
    }
}
