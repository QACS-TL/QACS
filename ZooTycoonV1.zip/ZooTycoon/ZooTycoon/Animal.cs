﻿namespace ZooTycoon
{
    public class Animal
    {
        public string name;
        public int limbCount;
        public string colour;
        private int health = 100;

        public string Eat(string food)
        {
            health += 5;
            return $"I'm a {colour} animal called {name} using some of my {limbCount} limbs to eat {food}.";
        }

        public string Move(string direction)
        {
            health -= 1;
            return $"I'm a {colour} animal called {name} using some of my {limbCount} limbs to move {direction}.";
        }
    }
}
