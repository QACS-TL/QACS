﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Dictionary of dictionaries:
        // Subject -> (Student -> Score)
        Dictionary<string, Dictionary<string, int>> subjectScores = new Dictionary<string, Dictionary<string, int>>();

        // Add subjects
        subjectScores["Math"] = new Dictionary<string, int>();
        subjectScores["Science"] = new Dictionary<string, int>();

        // Add students and their scores
        subjectScores["Math"]["Alice"] = 95;
        subjectScores["Math"]["Bob"] = 88;

        subjectScores["Science"]["Alice"] = 90;
        subjectScores["Science"]["Charlie"] = 85;

        // Accessing data
        Console.WriteLine("Alice's Math score: " + subjectScores["Math"]["Alice"]);
        Console.WriteLine("Charlie's Science score: " + subjectScores["Science"]["Charlie"]);

        // Iterate over everything
        Console.WriteLine("\nAll scores:");
        foreach (KeyValuePair<string, Dictionary<string, int>> subject in subjectScores)
        {
            Console.WriteLine($"Subject: {subject.Key}");
            foreach (KeyValuePair<string, int> student in subject.Value)
            {
                Console.WriteLine($"  {student.Key}: {student.Value}");
            }
        }
    }
}

