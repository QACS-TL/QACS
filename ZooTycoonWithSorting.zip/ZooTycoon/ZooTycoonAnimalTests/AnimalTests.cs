//using System.Drawing;
//using System.Xml.Linq;
//using ZooTycoon;

//namespace ZooTycoonAnimalTests
//{
//    public class AnimalTests
//    {
//        [Fact]
//        public void AnimalCreationTest()
//        {
//            //Arrange + Act
//            Animal animal = new Animal();
//            animal.Name = "Fido";
//            animal.LimbCount = 4;
//            animal.Colour = "Brown";

//            //Assert
//            Assert.Equal("Fido", animal.Name);
//            Assert.Equal(4, animal.LimbCount);
//            Assert.Equal("Brown", animal.Colour);
//        }

//        [Fact]
//        public void AnimalConstructorTest()
//        {
//            //Arrange + Act
//            Animal animal = new Animal();

//            //Assert
//            Assert.Equal("Anonymous", animal.Name);
//            Assert.Equal(4, animal.LimbCount);
//            Assert.Equal("Tan", animal.Colour);
//        }


//        [Fact]
//        public void AnimalConstructorWithParametersTest()
//        {
//            //Arrange + Act
//            Animal animal = new Animal("Dobbin", 5, "Stripey");

//            //Assert
//            Assert.Equal("Dobbin", animal.Name);
//            Assert.Equal(5, animal.LimbCount);
//            Assert.Equal("Stripey", animal.Colour);
//        }


//        [Fact]
//        public void AnimalNegativeLimbCountTest()
//        {
//            //Arrange 
//            Animal animal = new Animal("Dobbin", 5, "Stripey");

//            //Act
//            animal.LimbCount = -1;
//            //animal.SetLimbCount(-1);

//            //Assert
//            Assert.Equal("Dobbin", animal.Name);
//            Assert.Equal(0, animal.LimbCount);
//            //Assert.Equal(0, animal.GetLimbCount());
//            Assert.Equal("Stripey", animal.Colour);
//        }

//        [Fact]
//        public void CreateTwoAnimalsTest()
//        {
//            //Arrange + Act
//            Animal animal1 = new Animal();
//            animal1.Name = "Fido";
//            animal1.LimbCount = 4;
//            animal1.Colour = "Brown";

//            Animal animal2 = new Animal() { Name = "Fifi", LimbCount = 3, Colour = "Pink" };


//            //Assert
//            Assert.Equal("Fido", animal1.Name);
//            Assert.Equal(4, animal1.LimbCount);
//            Assert.Equal("Brown", animal1.Colour);

//            Assert.Equal("Fifi", animal2.Name);
//            Assert.Equal(3, animal2.LimbCount);
//            Assert.Equal("Pink", animal2.Colour);
//        }


//        [Fact]
//        public void CreateTwoAnimalsAndGetThemToEatTest()
//        {
//            //Arrange 
//            Animal animal1 = new Animal();
//            animal1.Name = "Fido";
//            animal1.LimbCount = 4;
//            animal1.Colour = "Brown";

//            Animal animal2 = new Animal();
//            animal2.Name = "Fifi";
//            animal2.LimbCount = 3;
//            animal2.Colour = "Pink";

//            string expectedMessage1 = $"I'm a Brown animal called Fido using some of my 4 limbs to eat Cheese.";
//            string expectedMessage2 = $"I'm a Pink animal called Fifi using some of my 3 limbs to eat Banana.";

//            //Act
//            string message1 = animal1.Eat("Cheese");
//            string message2 = animal2.Eat("Banana");

//            //Assert
//            Assert.Equal(expectedMessage1, message1);
//            Assert.Equal(expectedMessage2, message2);

//        }


//        [Fact]
//        public void CreateAnAnimalsAndGetItToMoveTest()
//        {
//            //Arrange 
//            Animal animal1 = new Animal();
//            animal1.Name = "Fido";
//            animal1.LimbCount = 4;
//            animal1.Colour = "Brown";

//            string expectedMessage1 = $"I'm a Brown animal called Fido using some of my 4 limbs to move North.";
//            string expectedMessage2 = $"I'm a Brown animal called Fido using some of my 4 limbs to move Up for 5 metres.";
//            string expectedMessage3 = $"I'm a Brown animal called Fido using some of my 4 limbs to move for 10 metres.";

//            //Act
//            string message1 = animal1.Move("North");
//            string message2 = animal1.Move("Up", 5);
//            string message3 = animal1.Move(10);

//            //Assert
//            Assert.Equal(expectedMessage1, message1);
//            Assert.Equal(expectedMessage2, message2);
//            Assert.Equal(expectedMessage3, message3);

//        }
//    }
//}