﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooTycoon
{
    public class Dragon:Animal
    {
        public Dragon():this("Dewi", 6, "Red", 100)
        {
            
        }

        public Dragon(string name, int limbCount, string colour, int fuelLevel):base(name, limbCount, colour) 
        {
            this.FuelLevel = fuelLevel;
        }

        private int fuelLevel;

        public int FuelLevel
        {
            get { return fuelLevel; }
            set { 
                if (value < 0)
                {
                    value = 0;
                }
                fuelLevel = value; 
            }
        }

        public string BreatheFire(int duration)
        {
            FuelLevel -= duration;
            if (FuelLevel > 0)
                return $"I'm a {Colour} dragon called {Name} ROASTING you for {duration} seconds.";
            return "Out of juice :-(";
        }

        public override string Eat(string food)
        {
             return $"I'm a {Colour} DRAGON called {Name} using my {LimbCount} limbs to  ROAST {food} and then, once done, chomping it but leaving some of the bones.";
        }
    }
}
