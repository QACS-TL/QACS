﻿namespace ZooTycoon
{
    //Must Inherit
    public abstract class Animal:IComparable<Animal>
    {
        public string Name { get; set; }
        public string Colour { get; set; }

        private int health = 100;

        public Animal():this("Anonymous", 4, "Tan")
        {
            //Name = "Anonymous";
            //limbCount = 4;
            //Colour = "Tan";
        }

        public Animal(string Name, int limbCount, string Colour)
        {
            this.Name = Name;
            this.LimbCount = limbCount;
            this.Colour = Colour;
        }

        //OLD Way that sucks
        //public int GetLimbCount()
        //{
        //    return limbCount;
        //}

        //public void SetLimbCount(int value)
        //{
        //    if (value < 0)
        //    {
        //        value = 0;
        //    }
        //    limbCount = value;
        //}

        private int limbCount;
        public int LimbCount
        {
            get { 
                return limbCount; 
            }
            set {
                if (value < 0)
                {
                    value = 0;
                }
                limbCount = value;
            }
        }

        //Must Override
        public abstract string Eat(string food);


        public string Move(string direction)
        {
            health -= 1;
            return $"I'm a {Colour} animal called {Name} using some of my {LimbCount} limbs to move {direction}.";
        }

        public string Move(int distance)
        {
            health -= 1;
            return $"I'm a {Colour} animal called {Name} using some of my {LimbCount} limbs to move for {distance} metres.";
        }

        public string Move(string direction, int distance)
        {
            health -= 1;
            return $"I'm a {Colour} animal called {Name} using some of my {LimbCount} limbs to move {direction} for {distance} metres.";
        }

        public int CompareTo(Animal? other)
        {
            //return this.LimbCount - other.LimbCount;
            return this.Name.CompareTo(other.Name);
        }
    }
}
