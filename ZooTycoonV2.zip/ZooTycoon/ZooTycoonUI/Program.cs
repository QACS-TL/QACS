﻿using ZooTycoon;


Animal animal1 = new Animal();
animal1.Name = "Fido";
animal1.LimbCount = 4;
animal1.Colour = "Brown";

Animal animal2 = new Animal();
animal2.Name = "Fifi";
animal2.LimbCount = 3;
animal2.Colour = "Pink";

Console.WriteLine($"I am a {animal1.Colour} animal called {animal1.Name} and I have {animal1.LimbCount} limbs.");
Console.WriteLine($"I am a {animal2.Colour} animal called {animal2.Name} and I have {animal2.LimbCount} limbs.");

