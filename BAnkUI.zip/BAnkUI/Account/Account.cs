﻿using System.Runtime.CompilerServices;

namespace BankAccounts
{
    public class Account
    {
        public string Name = "Anonymous";
        public string AccountNumber = "XXXXXX";
        public decimal Balance = 0;

        public decimal Credit(decimal amount) {
            return Balance += amount;
        }

        public decimal Debit(decimal amount) { 
            return Balance -= amount;
        }

        public void Transfer(Account account, decimal amount)
        {
            account.Credit(amount);
            this.Debit(amount);
        }
    }
}
