﻿using System.Runtime.CompilerServices;

namespace BankAccounts
{
    public class Account
    {
        public string Name;
        public string AccountNumber;


        public Account():this("Anonymous", "XXXXXX", 0.00m)
        {
            
        }

        public Account(string name, string accountNumber, decimal balance)
        {
            this.Name = name;
            this.AccountNumber = accountNumber;
            this.Balance = balance;
        }

        private decimal balance;

        public decimal Balance
        {
            get { return balance; }
            set {
                if (value < 0) // balance cannot be negative
                {
                    value = 0; 
                }
                balance = value; 
            }
        }


        public decimal Credit(decimal amount) {
            if (amount < 0) //amount must be a positive number
            {
                amount = 0;
            }
            return Balance += amount;
        }

        public decimal Debit(decimal amount) {
            if (amount < 0 || Balance - amount < 0) // amount must be a positive number and can't go below zero 
            {
                amount = 0;       
            }
            return Balance -= amount;
        }

        public void Transfer(Account account, decimal amount)
        {
            account.Credit(amount);
            this.Debit(amount);
        }

        //public List<string> GenerateStatement()
        //{
        //    List<Account> transactions = new List<Account>();
        //    // populate with transactions

        //    return transactions;

        //}
    }
}
