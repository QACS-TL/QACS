using BankAccounts;

namespace BankTests
{
    public class AccountTests
    {
        [Fact]
        public void CreateAnAccount()
        {
            //Arrange + Act
            Account account1 = new Account();
            account1.Name = "Irma Person";
            account1.AccountNumber = "123456";
            account1.Balance = 100.00m;

            //Assert
            Assert.Equal("Irma Person", account1.Name);
            Assert.Equal("123456", account1.AccountNumber);
            Assert.Equal(100.00m, account1.Balance);
        }

        [Fact]
        public void CreateAnAccountUsingDefaultConstructor()
        {
            //Arrange + Act
            Account account1 = new Account();

            //Assert
            Assert.Equal("Anonymous", account1.Name);
            Assert.Equal("XXXXXX", account1.AccountNumber);
            Assert.Equal(0.00m, account1.Balance);
        }

        [Fact]
        public void CreateAnAccountUsingParameterisedConstructor()
        {
            //Arrange + Act
            Account account1 = new Account("Irma Person", "123456", 100.00m);

            //Assert
            Assert.Equal("Irma Person", account1.Name);
            Assert.Equal("123456", account1.AccountNumber);
            Assert.Equal(100.00m, account1.Balance);
        }


        [Fact]
        public void BalanceCantBeNegative()
        {
            //Arrange
            Account account1 = new Account("Irma Person", "123456", 100.00m);

            //Act
            account1.Balance = -1.00m;

            //Assert
            Assert.Equal("Irma Person", account1.Name);
            Assert.Equal("123456", account1.AccountNumber);
            Assert.Equal(0.00m, account1.Balance);
        }

        [Fact]
        public void TryToDebitAccountWhereBalanceWouldGoNegative()
        {
            //Arrange
            Account account1 = new Account("Irma Person", "123456", 100.00m);

            //Act
            account1.Debit(101.00m);

            //Assert
            Assert.Equal("Irma Person", account1.Name);
            Assert.Equal("123456", account1.AccountNumber);
            Assert.Equal(100.00m, account1.Balance);
        }


        [Fact]
        public void TryToDebitAccountWithNegativeAmount()
        {
            //Arrange
            Account account1 = new Account("Irma Person", "123456", 100.00m);

            //Act
            account1.Debit(-50.00m);

            //Assert
            Assert.Equal("Irma Person", account1.Name);
            Assert.Equal("123456", account1.AccountNumber);
            Assert.Equal(100.00m, account1.Balance);
        }


        [Fact]
        public void TryToCreditAccountWithNegativeAmount()
        {
            //Arrange
            Account account1 = new Account("Irma Person", "123456", 100.00m);

            //Act
            account1.Credit(-50.00m);

            //Assert
            Assert.Equal("Irma Person", account1.Name);
            Assert.Equal("123456", account1.AccountNumber);
            Assert.Equal(100.00m, account1.Balance);
        }

        [Fact]
        public void CreateTwoAccounts()
        {
            //Arrange + Act
            Account account1 = new Account();
            account1.Name = "Irma Person";
            account1.AccountNumber = "123456";
            account1.Balance = 100.00m;

            Account account2 = new Account() {
                Name="Wanda IfIveAnyMoney", AccountNumber="222222", Balance=5.00m };

            //Assert
            Assert.Equal("Irma Person", account1.Name);
            Assert.Equal("123456", account1.AccountNumber);
            Assert.Equal(100.00m, account1.Balance);

            Assert.Equal("Wanda IfIveAnyMoney", account2.Name);
            Assert.Equal("222222", account2.AccountNumber);
            Assert.Equal(5.00m, account2.Balance);
        }

        [Fact]
        public void CreditAnAccount()
        {
            //Arrange
            Account account1 = new Account();
            account1.Name = "Irma Person";
            account1.AccountNumber = "123456";
            account1.Balance = 100.00m;

            //Act
            decimal retNewBal = account1.Credit(50.00m);

            //Assert
            Assert.Equal(150.00m, account1.Balance);
            Assert.Equal(150.00m, retNewBal);
        }

        [Fact]
        public void DebitAnAccount()
        {
            //Arrange
            Account account1 = new Account();
            account1.Name = "Irma Person";
            account1.AccountNumber = "123456";
            account1.Balance = 100.00m;

            //Act
            decimal retNewBal = account1.Debit(50.00m);

            //Assert
            Assert.Equal(50.00m, account1.Balance);
            Assert.Equal(50.00m, retNewBal);
        }

        [Fact]
        public void TransferBetweenAccounts()
        {
            //Arrange
            Account account1 = new Account();
            account1.Name = "Irma Person";
            account1.AccountNumber = "123456";
            account1.Balance = 100.00m;

            Account account2 = new Account() { 
                Name = "Wanda IfIveAnyMoney", AccountNumber = "222222", Balance = 5.00m };

            //Act
           account1.Transfer(account2, 25.00m);

            //Assert
            Assert.Equal(75.00m, account1.Balance);
            Assert.Equal(30.00m, account2.Balance);
        }
    }
}