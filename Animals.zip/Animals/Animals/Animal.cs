﻿namespace Animals
{
    public class Animal
    {
        public string Name = "Anon";
        public int LimbCount = 4;
        public string Colour = "Brown";
        public int Health = 100;

        public string Eat(string food)
        {
            Health += 5;
            if (Health > 100) {
                Health = 100;
            }

            return $"I'm a {Colour} animal called {Name} using my {LimbCount} limbs to eat {food}";
        }

        public string Move(string direction)
        {
            return $"I'm an animal called {Name} moving {direction}";
        }

        public string Move(int distance)
        {
            return $"I'm an animal called {Name} moving {distance} metres";
        }

        public string Move(int distance, string direction)
        {
            return $"I'm an animal called {Name} moving {direction} for {distance} metres";
        }

    }
}
