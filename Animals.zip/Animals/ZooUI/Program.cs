﻿using Animals;

Animal animal = new Animal();
animal.Name = "Fifi";
animal.LimbCount = 5;
animal.Colour = "Pink";
animal.Health = 95;

Animal animal2 = new Animal();
animal2.Name = "Fido";
animal2.LimbCount = 3;
animal2.Colour = "Yellow";
animal2.Health = 25;

Console.WriteLine(animal.Eat("banana cake"));
Console.WriteLine(animal2.Eat("brownie"));

List<Animal> animals = new List<Animal>();
animals.Add(animal);
animals.Add(animal2);
animals.Add(new Animal { Name="Bonzo", Colour="Green", LimbCount=6});

foreach(Animal ani in animals)
{
    Console.WriteLine(ani.Move(10, "North"));
}


